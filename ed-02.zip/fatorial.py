import  pprint;
print ('Hello World')

def fatorial(n, show=False):
    fat = 1
    for c in range(n, 0, -1):
        if show:
            print(f'{c} x ', end= '')
        fat *= c
    return fat
    

lista = []
i = 0
for i in range(i, 10, 1):
    lista.append(fatorial(i))
   
print(lista)

novaLista = lista[::-1]

print(novaLista)
p = ','.join(lista)
count = {}
    
    