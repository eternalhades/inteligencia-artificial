num = input('digite um numero')

num = float(num);

if num > 1 :
    n1 = num // 1;
    num = num % 1;
    print(f' 1,00 * {n1}')
    
if num >  0.5:
    n1 = num // 0.5;
    num = num % 0.5
    print(f' 0,50 * {n1}')
if num > 0.25 :
    n1 = num // 0.25;
    num = num % 0.25
    print(f' 0,25 * {n1}')
if num > 0.1:
    n1 = num // 0.1;
    num = num % 0.1
    print(f' 0,10 * {n1}')
if num > 0.05:
    n1 = num // 0.05;
    num = num % 0.05
    print(f' 0,05 * {n1}')
if num > 0.01:
    n1 = num // 0.01;
    num = num % 0.01
    print(f' 0.01 * {n1}')