from typing import List
import random
from random import uniform

# Problema
# 1. Função objetivo - teste do objetivo
def f(x: float) -> float:
    return 269 - x == 0;

# 2. Estado inicial
def get_ei():
    return random.choice(pesos)

# 3. Ações
# - Somar ou subtrair valores entre 0 e 0.5

# 4. Função sucessora
pesos = [95, 4, 60, 32, 23, 72, 80, 62, 65, 46]
ouro = [55, 10, 47, 5, 4, 50, 8, 61, 85, 87]
def funcao_sucessora(x: float) -> List[float]:
    return [random.choice(pesos) for _ in range(10)]


# 5. Custo do caminho
# - Não se aplica
def simulated_annealing():
    estado_atual = get_ei()
    estado_melhor = estado_atual
    lista = []
    i = 0
    y = 269;
    T = uniform(810, 1000);
    while True:
        vizinhanca = funcao_sucessora(estado_atual)
        
        for v in vizinhanca:
            if f(v) >= f(estado_atual) and f(v) >= f(estado_melhor) and y >= f(estado_melhor) and y >= f(estado_atual):
                if y > 0:
                    estado_melhor = v
                    lista.append(estado_melhor)
                    print(f' {y} - {estado_melhor}')
                    y = y - estado_melhor
                    
            else:
                if T / 2 > y:
                    if y > 0:
                        estado_melhor = v
                        lista.append(estado_melhor)
                        print(f' {y} - {estado_melhor}')
                        y = y - estado_melhor
                        
            
    
        
        i += 1
        lista.pop(-1);
        return lista;

    
print(f'* Melhor solucao: {simulated_annealing()}')